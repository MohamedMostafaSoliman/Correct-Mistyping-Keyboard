

function ConvertFunc() {
    "use strict";
    var engilsh_char = [" ", "`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
                           "-", "=", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "a", "s", "d",
                            "f", "g", "h", "j", "k", "l", ";", "'", "z", "x", "c", "v", "b", "n",
                            "m", ",", ".", "/", "~", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")",
                           "_", "+", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "{", "}",
                           "A", "S", "D", "F", "G", "H", "J", "K", "L", ":", "Z", "X", "C", "V",
                           "B", "N", "M", "<", ">", "?"];
    var arabic_char = [" ", "ذ", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-",
                          "=", "ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د", "ش", "س", "ي", "ب", "ل",
                          "ا", "ت", "ن", "م", "ك", "ط", "ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ", "ّ", "!", "@",
                          "#", "$", "%", "^", "&", "*", ")", "(", "_", "+", "َ", "ً", "ُ", "ٌ",
                          "لإ", "إ", "‘", "÷", "×", "؛", "<", ">", "ِ", "ٍ", "]", "[", "لأ", "أ", "ـ", "،", "/", ":", "~", "ْ",
                          "}", "{", "لآ", "آ", "’", ",", ".", "؟"];

    var mytext = document.getElementById("textarea").value, eng = 0, ara = 0, i = 0, eng_counter = 0, ara_counter = 0, inner_eng_counter = 0, inner_ara_counter = 0, identifi, outputtext = "";
    while (i < engilsh_char.length) {
        if (mytext[0] === engilsh_char[i]) {
            eng = 1;
            break;
        }
        if (mytext[0] === arabic_char[i]) {
            ara = 1;
            break;
        }
        i = i + 1;
    }
    if (eng === 1) {

        while (eng_counter < mytext.length) {
            while (inner_eng_counter < engilsh_char.length) {
                if (mytext[eng_counter] === engilsh_char[inner_eng_counter]) {
                    identifi = inner_eng_counter;
                    break;
                }
                inner_eng_counter += 1;
            }
            outputtext += arabic_char[identifi];
            eng_counter += 1;
            inner_eng_counter = 0;
        }
        document.getElementById("textarea").value = outputtext;
        outputtext = "";
        identifi = 0;

    } else if (ara === 1) {
        while (ara_counter < mytext.length) {
            while (inner_ara_counter < arabic_char.length) {
                if (mytext[ara_counter] === arabic_char[inner_ara_counter]) {
                    identifi = inner_ara_counter;
                    break;
                }
                inner_ara_counter += 1;
            }
            outputtext += engilsh_char[identifi];
            ara_counter += 1;
            inner_ara_counter = 0;
        }
        document.getElementById("textarea").value = outputtext;
        outputtext = "";
        identifi = 0;
    }

}
var mybtn = document.getElementById('mybtn');

mybtn.addEventListener('click', ConvertFunc);
